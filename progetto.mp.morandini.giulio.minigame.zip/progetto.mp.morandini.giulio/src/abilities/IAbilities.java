package abilities;

public interface IAbilities {

	public int attack();

	public void gainStamina();

}