package strategies;

public interface IBossMode {

	public int applyMode(int originalAttack);

}
